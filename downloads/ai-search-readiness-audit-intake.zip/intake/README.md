# Your AI Search Readiness Audit — next step (30 seconds)

Thanks for the purchase. Here is exactly what happens now.

## 1. Send us your domain

Email **steelworksintelligence@gmail.com** with:

- Subject: `Audit — <your domain>`
- Body: your website domain (e.g. `example.com`), and your business name if
  the site doesn't make it obvious.

If you filled the domain field at checkout, you can skip this — we already
have it.

## 2. We run the audit

Our automated pipeline checks your domain's technical readiness for AI
crawlers, probes the AI engines for entity recognition of your business,
runs a citation-gap analysis on customer-style questions, and compiles a
prioritized fix list. Every report passes a quality gate before it ships.

## 3. Report in your inbox within 72 hours

The report arrives at the email you purchased with (or the one you write
from, if different — say so in your email). It is a written document with a
scorecard, findings, and copy-pasteable fixes. Anything our pipeline could
not assess for your specific domain is listed as "not assessed" with the
reason — we do not pad reports.

## Questions or problems

Email steelworksintelligence@gmail.com. If we miss the 72-hour window for
any reason, tell us and we will make it right or refund you.

— SteelWorks Intelligence · therealmacsteel.github.io
