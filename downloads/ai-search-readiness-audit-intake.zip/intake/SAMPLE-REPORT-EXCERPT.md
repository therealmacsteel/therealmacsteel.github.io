# SAMPLE — what your report looks like

This is a real excerpt from this exact audit run against OUR OWN domain (therealmacsteel.github.io) on 2026-08-03. We scored 37.5/100 — NOT AI-READY. We publish that number because honest receipts are the whole brand; your report gets the same honesty.

---

# AI Search Readiness Audit — therealmacsteel.github.io

**Prepared for:** <buyer email>  
**Audit date:** 2026-08-03 12:11 UTC  
**Business identified on site:** SteelWorks Intelligence

## Verdict: NOT AI-READY — 37.5/100

## Scorecard

| Leg | Score | Weight | Status |
|---|---|---|---|
| Technical readiness | 75.0/100 | 50% | assessed |
| Entity recognition | 0.0/100 | 25% | assessed (3 probes) |
| Citation presence | 0.0/100 | 25% | assessed (5 queries) |
| **Overall** | **37.5/100** | (reweighted over assessed legs) | NOT AI-READY |

## 1. Technical readiness

| Check | Points | Max |
|---|---|---|
| AI crawlers allowed in robots.txt (4/4 allowed, 0 partial) | 30 | 30 |
| llms.txt present (yes) | 10 | 10 |
| sitemap.xml valid (45 <loc> entries) | 15 | 15 |
| title tag quality (63 chars) | 10 | 10 |
| meta description (0 chars) | 0 | 10 |
| JSON-LD schema (types: none) | 0 | 15 |
| h1 structure (1 h1 tags) | 5 | 5 |
| homepage load size (13 KB html) | 5 | 5 |

**AI crawler access (robots.txt):**

- GPTBot: ALLOWED
- ClaudeBot: ALLOWED
- PerplexityBot: ALLOWED
- Google-Extended: ALLOWED

- Title: "SteelWorks Intelligence — Build in public. Automate everything."
- Meta description: MISSING
- JSON-LD types found: none
- llms.txt: present · sitemap.xml: valid, 45 URLs · favicon: missing
- Homepage HTML size: 13 KB



…(full report includes entity probes, citation-gap and prioritized fixes with copy-pasteable code)…

---

## Methodology — what was automated, and what was not

- Leg 1 is a deterministic automated crawl of your homepage, robots.txt, llms.txt, sitemap.xml and favicon performed at the audit date above; every score line maps to a listed check.
- Legs 2-3 are live probes of production AI engines; excerpts quoted are the engines' real responses. Classification uses the engine's own stated confidence plus string heuristics.
- Engines that answered this run: openrouter/nemotron-3-ultra-550b-a55b:free (cloud API).
- The overall score is reweighted across assessed legs only; unassessed legs never silently count as zero or full marks.
- No competitor citation in this report was invented; leg-3 names come verbatim from engine responses.

---

Produced by SteelWorks Intelligence's automated audit pipeline · 2026-08-03 12:11 UTC · questions → steelworksintelligence@gmail.com
