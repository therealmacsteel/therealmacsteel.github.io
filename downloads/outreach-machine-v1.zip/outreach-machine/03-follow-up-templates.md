# Follow-Up Templates — two touches, then stop

Rules first (they matter more than the words): follow-up 1 on day 3,
follow-up 2 on day 10, then nurture-or-close. Every follow-up ADDS something.
Every send carries the compliance footer. All caps/frequency rules from the
playbook still apply. `{observation}`, `{company}`, `{useful-thing}` are YOUR
inputs — if you can't fill them specifically, don't send. The gate skill will
block placeholders that survive editing, but don't make it work that hard.

---

## First touch (the four-beat structure, for reference)

Subject: `{Specific useful thing} for {company}`

> Hi {name},
>
> {Observation — one sentence about THEM that a stranger would recognize as true.}
>
> I {one sentence: who you are, what you actually do}. For {company}, the
> useful version would be {specific thing}: {one sentence of what it does and
> what it would tell them}.
>
> If useful, I can send {the exact deliverable} — no call needed.
>
> {Your name}
> {Footer — see compliance rails}

## Follow-up 1 (day 3) — add a resource

Subject: `Re: {original subject}`

> Hi {name} — following up with something concrete rather than a bump:
>
> {One resource, number, or idea they can use WITHOUT replying — a checklist,
> a benchmark for their niche, a one-paragraph teardown. Give it away here.}
>
> The offer from my last note stands: {restate the deliverable in half a
> sentence}. Worth a look?
>
> {Your name}
> {Footer}

## Follow-up 2 (day 10) — the honest close

Subject: `Re: {original subject}`

> Hi {name} — last note from me on this.
>
> If {the problem} isn't a priority right now, that's a completely reasonable
> answer and I'll close the thread. If it is, the fastest version: {the
> smallest possible starting step, stated in one sentence}.
>
> Either way — {one genuinely warm, specific sign-off line related to the
> observation. Not flattery. Something true.}
>
> {Your name}
> {Footer}

## Reply skeletons (interested / question)

**Interested:** answer in under 100 words, deliver the promised thing IN the
reply or attached to it (no "let's hop on a call" bait-and-switch), end with
one scoping question that routes the conversation.

**Question:** answer the actual question first, completely, even if the
answer reduces your pitch. Honesty converts better than persistence —
and it's the operating rule of a receipts brand: the answer is the answer.

## What is deliberately missing

No "breakup email" guilt lines, no fake scarcity, no "did my email get
buried?" theater, no send-time hacks. None of that survives a quality gate
with an honesty dimension, and none of it builds a sender reputation you can
keep.
