# Setup Guide — manual in 30 minutes, automated when it earns it

## Track A — the manual loop (start here, genuinely)

Day 0 (30-60 min):
1. Make the sheet: columns = company, contact, email, observation, signal
   source, stage (new/drafted/approved/sent/f1/f2/replied/closed/SUPPRESSED),
   last-touch date.
2. Create your footer (compliance rails §1) as a text snippet.
3. Create a "Suppressed" tab. This tab is law. Check it before every send.
4. Save the two follow-up templates + first-touch structure as drafts.

Daily loop (~30 min):
1. 10 min — signals: scan your 2-3 signal sources (playbook Part 1), add
   leads WITH their observation. No observation, no row.
2. 10 min — draft: write first-touches for up to 5 leads. Run each through
   the quality-gate skill (paste draft + SKILL.md into any LLM, or use the
   hard-fail list as a manual checklist). 85+ ships.
3. 5 min — send the approved ones. Log in the sheet.
4. 5 min — replies: classify per the rails (§3 traps!), update stages,
   suppress opt-outs immediately, queue follow-ups due today.

## Track B — free automation (after 2+ weeks of manual)

Automate in THIS order — each step only after the manual version hurts:
1. **Signal collection** (lowest risk): a script or RSS reader pulling your
   sources into an inbox. Read-only, can't embarrass you.
2. **Draft generation** (medium): any free/local LLM + the gate skill.
   The gate is the point — generation without the gate is spam-at-scale.
   Wire the hard-fail list as literal string/regex checks in code; LLM
   self-assessment is not a gate.
3. **Follow-up scheduling** (medium): calendar or cron reminders from your
   sheet's dates. Keep the SEND human.
4. **Sending** (highest risk, automate LAST if ever): if you do — the
   suppression check goes in the send function itself, the daily cap is
   enforced in code, and every send appends to the log first. Approval
   stays human until you have months of clean ledger.

Free stack that runs all of this: any spreadsheet, any calendar, a local LLM
runner (Ollama and similar are free), and ~200 lines of any scripting
language for the pieces you graduate to. No specific SaaS required — that's
the point of the system.

## The four numbers to watch weekly

1. Sends (delivered, from the log — not attempts)
2. Reply rate (any human reply / delivered)
3. Positive-reply rate (interested+question / delivered)
4. Suppression events (opt-outs are FEEDBACK: rising rate = your targeting
   or copy drifted; the gate's honesty dimension usually finds it)

Honest calibration: single-digit reply rates are normal for cold outreach done right. Anyone promising 40% reply rates is
selling you the promise, not the rate.
