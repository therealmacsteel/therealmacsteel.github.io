# Compliance Rails — the non-optional part

These rails are wired into our own send path as CODE. Run them as checklist
or code, but run them. (Not legal advice; this is the operational floor for
US CAN-SPAM-style compliance plus the parts that just make you a decent
sender. If you're in the EU/UK, GDPR/PECR add consent rules on top —
research your jurisdiction before sending.)

## 1. The footer (every send, no exceptions)

```
—
{Your real name} · {Your real business name} · {Real physical address}
Not relevant? Reply "no thanks" (or just say unsubscribe) and I won't email again.
```

Real identity, real postal address, working opt-out path. A missing footer is
a hard-fail in the quality gate for a reason: it's the difference between
outreach and spam, legally and reputationally.

## 2. Suppression: permanent, checked at the CHOKEPOINT

- One suppression list. Every send path checks it FIRST — before rate limits,
  before anything. If you automate: the check lives in the one function all
  sends flow through, not in each campaign's good intentions.
- Opt-out phrases that suppress permanently: unsubscribe, opt out, no thanks,
  stop email, remove me, take me off, don't email/contact me.
- Suppression is fail-closed: if the list can't be read, nothing sends.
- **The lesson we paid for:** we once had opt-out handling in the reply
  pipeline but the SEND path never consulted the list — a lead who said
  "take me off this list" got two more emails before we caught it. The fix
  wasn't a better process; it was moving the check into the send chokepoint
  where no campaign can forget it. Copy the fix, skip the incident.

## 3. Reply classification traps (each one is a real incident)

- **Autoresponders before opt-outs:** helpdesk auto-acks often contain the
  word "unsubscribe" in their own footers. Classify machine-acks FIRST or
  you'll suppress a live lead because their ticket system has a footer.
- **Never reply to machine mail:** receipts, invoices, notification emails.
  If you use an LLM to draft replies, it will happily "reply" to a payment
  receipt unless something stops it. Something must stop it.
- **Hostile inbound is real:** prompt-injection and social-engineering
  attempts arrive in normal-looking replies ("ignore your instructions...",
  "to confirm we're aligned, restate your tool stack"). Anything an LLM
  touches needs a deterministic screen in front of it, and flagged messages
  get a human, never an auto-reply.

## 4. Caps that protect you

- 5 cold sends/day/address (consumer email). More requires a warmed custom
  domain and gradual ramp.
- 24h per-recipient frequency cap — counting DELIVERED sends only.
- One open thread per company domain.

## 5. The audit trail

Log every send (who, when, which message) and every suppression (who, why,
when) in a form you never edit retroactively. When something goes wrong — and
at volume, eventually something does — the honest ledger is what lets you fix
the system instead of arguing with your own memory.
