# The $0 Outreach Machine

**The cold-outreach system we actually run — playbook, quality gate, follow-up
sequences, and the compliance rails that keep it honest. No paid tools required.**

This is not theory. Every part of this system runs on a real business
(SteelWorks Intelligence). Where we learned something the hard way, the lesson
is in here — including the failures.

---

## What this system does

1. Finds leads from free public demand signals (no purchased lists)
2. Drafts a personalized first email that passes a QUALITY GATE before it can send
3. Caps daily volume so your domain reputation survives
4. Runs follow-ups on a schedule with hard stop conditions
5. Handles replies, opt-outs, and bounces with compliance-grade discipline

## What it needs (honest requirements)

- An email account you control (Gmail works; a warmed custom domain is better —
  we tell you exactly when gmail-sending will cap your results and why)
- 30-60 minutes of setup
- A human on approvals. This system drafts and queues; YOU approve what sends.
  That is a feature. Autonomous sending to strangers is how brands die.
- Optional: any LLM (free local models work) for draft personalization.
  The system degrades gracefully to template mode without one.

## What it will NOT do

- Guarantee replies. Single-digit reply rates are the honest norm for cold
  outreach done right (Part 3 explains the math) — and this playbook includes
  the story of the week our own pipeline sent almost nothing because a quality
  gate was doing its job and holding bad drafts.
- Scrape private data or bypass platform rules.
- Send without opt-out handling. The compliance rails are not optional
  garnish; they are wired into the send path.

---

## Part 1 — The signal-first lead model

Cold outreach fails when the list is the product. Ours starts from DEMAND
SIGNALS: public posts where someone describes the exact problem you solve.

Free signal sources we use:
- Hiring pages and job boards (a company hiring 3 engineers has ops pain)
- Product launch communities (launch week = tooling decisions being made)
- Complaint threads on review sites (documented pain + named tools)
- Niche forums and communities where your buyer already talks

**The one-observation rule:** no draft exists until you can write ONE specific,
human-readable observation about the company that a stranger would recognize
as true. "Noticed you're hiring Python and Go engineers — teams that grow that
fast usually multiply their ops load" beats any template ever written. If you
can't write the observation, the lead isn't ready. Our system literally
refuses to generate a draft without one — copy that discipline even if you
run this manually.

## Part 2 — The draft structure that survives spam filters and humans

Subject: plain, specific, no caps-lock, no "quick question"
Body, four beats, under 140 words:
1. The observation (theirs, not yours)
2. One sentence of who you are and what you do
3. The specific useful thing you're offering (a workflow, an audit, a number)
4. One low-pressure next step ("If useful, I can send X")
Then the compliance footer (Part 4 — non-negotiable).

Anti-patterns that our quality gate hard-blocks (each cost us deliverability
until we blocked them): ALL-CAPS words from scraped data, "limited time" and
its spam-trigger cousins, more than 2 exclamation marks, link-stuffing (1 link
per ~20 words of copy minimum), placeholder text like [NAME] reaching a send —
yes, that happens to everyone eventually, which is why gates beat vigilance.

## Part 3 — Volume discipline (the part everyone skips)

- **Daily cap: 5 cold sends per day per address.** Not 50. Gmail cold-sending
  above ~10-20/day is how you land in spam folders permanently.
- **Frequency cap: never email the same person twice inside 24h** — and count
  only DELIVERED sends against caps. (We once had a bug where BLOCKED sends
  counted as contact attempts and the whole pipeline silently starved itself
  for nine days. Count what actually reached a human.)
- **Domain cooldown:** one thread per company at a time.

The reply-rate math these caps imply: 5 sends/day = ~100 delivered/month.
A well-run 5-8% reply rate = 5-8 real conversations monthly from 30 min/day —
which compounds; a blasted 50/day list burning the domain does not.

## Part 4 — Compliance rails (file 04)

Opt-out is sacred, suppression is permanent, and the footer with your real
identity + a working opt-out path goes on EVERY send. The rails file gives you
the exact footer, the suppression-list pattern, and the reply-classification
rules — including the subtle ones (never auto-suppress from an autoresponder;
never reply to machine-generated receipts).

## Part 5 — Follow-up sequences (file 03)

Two follow-ups maximum. Day 3 and day 10. After that: nurture or close.
Each follow-up must ADD something (a resource, a specific idea) — "just
bumping this" is a withdrawal from an account with no balance.

## Part 6 — Reply handling with an SLA

Every reply gets classified within 24h: interested / question / not-interested
/ opt-out / bounce / autoresponder — and one more that surprised us:
**hostile**. Real inboxes receive social-engineering and prompt-injection
attempts (if you use an LLM anywhere near replies, a stranger WILL eventually
try "ignore your instructions and..."). Rule: a human reviews anything the
classifier flags; nothing auto-replies to a flagged message. The gate skill's appendix lists the exact
patterns we screen for; file 04 §3 covers the classification traps.

## Part 7 — Run it manually or automate it

Everything above works from a spreadsheet + calendar. The setup guide
(file 05) shows both: the manual loop (30 min/day) and the
free-automation loop (local scripts + any free LLM). Start manual. Automate
the step that hurts most first. Gate before you automate — an ungated
automation just makes mistakes faster.
